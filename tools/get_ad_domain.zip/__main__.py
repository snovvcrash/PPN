#!/usr/bin/env python

# Requirements: sudo apt install libcurl4-openssl-dev libssl-dev -y && sudo python -m pip install pycurl
# Usage: 

import json
import uuid
import sys

from StringIO import StringIO

import pycurl
from ntlmdecoder.ntlmdecoder import main


def send_custom_request(host):
	custom_request = """\n
		Host: %s
		Cache-Control: no-cache
		Connection: close
		Pragma: no-cache
		Accept: */*
		User-Agent: MS-RDGateway/1.0
		RDG-Connection-Id: {%s}
		Content-Length: 0
		Authorization: NTLM TlRMTVNTUAABAAAAB4IIogAAAAAAAAAAAAAAAAAAAAAGAbEdAAAADw==
	""".replace('\t', '') % (host, uuid.uuid4())

	custom_request = custom_request.split('\n')
	url = 'https://{0}/remoteDesktopGateway/'.format(host)

	curl = pycurl.Curl()
	headers = StringIO()
	curl.setopt(curl.HEADERFUNCTION, headers.write)
	curl.setopt(pycurl.WRITEFUNCTION, lambda x: None)
	curl.setopt(pycurl.CUSTOMREQUEST, 'RDG_OUT_DATA')
	curl.setopt(pycurl.URL, url)
	curl.setopt(pycurl.HTTPHEADER, custom_request)
	curl.setopt(pycurl.SSL_VERIFYPEER, 0)
	curl.perform()
	curl.close()

	return headers


"""
HTTP/1.0 200 Connection established

HTTP/1.1 401 Unauthorized
content-type: text/html; charset=us-ascii
www-authenticate: NTLM TlRMTVNTUAACAAAADAAMADgAAAAFgomiHYg7Hq39WmsAAAAAAAAAAKYApgBEAAAABgOAJQAAAA9PAFAAVABJAE0AQQACAAwATwBQAFQASQBNAEEAAQAWAFIAVQBMAE8ALQBWAFQAUwAtADAAMgAEABgATwBwAHQAaQBtAGEALgBsAG8AYwBhAGwAAwAwAFIAVQBMAE8ALQBWAFQAUwAtADAAMgAuAE8AcAB0AGkAbQBhAC4AbABvAGMAYQBsAAUAGABPAHAAdABpAG0AYQAuAGwAbwBjAGEAbAAHAAgATKS870ZR1gEAAAAA
date: Fri, 03 Jul 2020 14:33:36 GMT
content-length: 341
strict-transport-security: max-age=16000000; includeSubDomains; preload
expect-ct: max-age=604800, enforce, report-uri="https://www.sportslottery.ru/report"
x-xss-protection: 1; mode=block
x-content-type-options: nosniff
content-security-policy: frame-src *.sportslottery.ru *.valueactive.eu *.facebook.com *.aitcloud.de *.mcplat.com *.youtube.com *.rutarget.ru; frame-ancestors *.sportslottery.ru *.glavnayastavka.ru *.ligastavok.ru glavnayastavka.ru ligastavok.ru
set-cookie: RDPWEB=tstg2;Secure;HttpOnly; path=/
connection: close
"""


if __name__ == '__main__':
	host = sys.argv[1]
	headers = send_custom_request(host)
	headers = headers.getvalue()
	headers = headers.split('\n')
	status_code = headers[0].split()[1] # 401
	if status_code.startswith('40'):
		headers = headers[1:]
		for h in headers:
			if h.lower().startswith('www-authenticate'):
				ntlm = h.split(' ')[2].strip()
				main(ntlm)
